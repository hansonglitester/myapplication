package com.hsl.cn.service.impl;

import com.hsl.cn.pojo.dataobject.Task;
import com.hsl.cn.respority.TaskRespority;
import com.hsl.cn.service.TaskService;
import org.springframework.beans.factory.annotation.Autowired;

public class TaskServiceImpl implements TaskService {
    @Autowired
    TaskRespority taskRespority;

    @Override
    public boolean save(Task entity) {
        taskRespority.save(entity);
        return false;
    }
}
