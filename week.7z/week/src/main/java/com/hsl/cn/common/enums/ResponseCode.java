package com.hsl.cn.common.enums;
import lombok.Data;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

public enum  ResponseCode {

    SUCCESS("0000", "success"),
    FAIL("0001", "fail");

    private String code;
    private String desc;
    private static final Map<String, ResponseCode> lookup;

    static {
        lookup = new HashMap<>();
        for (ResponseCode e : EnumSet.allOf(ResponseCode.class)) {
            lookup.put(e.getCode(), e);
        }
    }

    public String getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

    ResponseCode(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public static ResponseCode get(String code) {
        return lookup.get(code);
    }
}
