package com.hsl.cn.service.impl;

import com.hsl.cn.pojo.dataobject.Project;
import com.hsl.cn.pojo.datatransferobject.ProjectDTO;
import com.hsl.cn.respority.ProjectRespority;
import com.hsl.cn.service.ProjectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProjectServiceImpl implements ProjectService {

    @Autowired
    ProjectRespority projectRespority;
    @Override
    public Boolean add(ProjectDTO projectDTO) {

        Project project=new Project();

        project.setName(projectDTO.getName());

        project.setRemark(projectDTO.getRemark());

        projectRespority.save(project);

        return  true;
    }

    @Override
    public boolean save(Project entity) {
        return false;
    }
}
