package com.hsl.cn.controller;

import com.hsl.cn.pojo.dataobject.Project;
import com.hsl.cn.pojo.datatransferobject.ProjectDTO;
import com.hsl.cn.pojo.viewobject.ResultEntity;
import com.hsl.cn.respority.ProjectRespority;
import com.hsl.cn.service.ProjectService;
import javafx.geometry.Pos;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/project")
public class ProjectController {

    @Autowired
    ProjectService projectService;

    @PostMapping("/add")
    public ResultEntity add(@RequestBody ProjectDTO projectDTO){

        projectService.add(projectDTO);

        return ResultEntity.ok();
    }

}

