package com.hsl.cn.service;

import com.hsl.cn.pojo.dataobject.Task;

public interface TaskService extends IService<Task>{

}
