package com.hsl.cn.service;

import com.hsl.cn.pojo.dataobject.Project;
import com.hsl.cn.pojo.dataobject.Task;
import com.hsl.cn.pojo.datatransferobject.ProjectDTO;
import com.hsl.cn.service.IService;

public interface ProjectService extends IService<Project>{

    public Boolean add(ProjectDTO projectDTO);

}
