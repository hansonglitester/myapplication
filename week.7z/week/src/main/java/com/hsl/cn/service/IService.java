package com.hsl.cn.service;

public interface IService<T> {

    boolean save(T entity);

}

