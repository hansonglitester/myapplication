package com.hsl.cn.respority;

import com.hsl.cn.pojo.dataobject.Project;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProjectRespority extends JpaRepository<Project,Integer> {
}
