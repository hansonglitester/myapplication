package com.hsl.cn.pojo.viewobject;

import lombok.Data;

@Data
public class ProjectVO {
    private Integer id;
    private  String  name;
    private  String  remark;
}
