package com.hsl.cn.service;

import com.hsl.cn.pojo.dataobject.Task;

import java.text.ParseException;

public interface TaskService extends IService<Task>{
}
