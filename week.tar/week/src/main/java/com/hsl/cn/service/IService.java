package com.hsl.cn.service;

public interface IService<T> {

    Boolean add(T entity);

}

